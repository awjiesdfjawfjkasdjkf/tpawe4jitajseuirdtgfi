# Guía de conexiones — ServerResourcePack

Cada ítem personalizado sigue esta cadena: **item → modelo → textura**

```
assets/minecraft/items/<item>.json      → decide qué modelo usar según custom_model_data
assets/minecraft/models/item/<x>.json   → decide qué textura usar (y de qué "parent" hereda)
assets/minecraft/textures/item/<x>.png  → la imagen final
```

## wooden_sword
| custom_model_data | modelo | textura |
|---|---|---|
| (sin dato / 0) | `models/item/wooden_sword.json` | vanilla (wooden_sword) |
| 1 | `models/item/wooden_sword_1.json` | `textures/item/wooden_sword/1.png` |
| 2 | `models/item/wooden_sword_2.json` | `textures/item/wooden_sword/2.png` |

## stone_sword
| custom_model_data | modelo | textura |
|---|---|---|
| (sin dato / 0) | `models/item/stone_sword.json` | vanilla (stone_sword) |
| 1 | `models/item/stone_sword_1.json` | `textures/item/stone_sword/1.png` |

## paper
| custom_model_data | modelo | textura |
|---|---|---|
| (sin dato / 0) | `models/item/paper.json` | vanilla (paper) |
| 1 | `models/item/papermoney.json` | `textures/item/paper/money.png` |
| 2 | `models/item/moneyminor.json` | `textures/item/paper/moneyminor.png` |

## writable_book
| custom_model_data | modelo | textura |
|---|---|---|
| (sin dato / 0) | `models/item/writable_book.json` | vanilla (writable_book) |
| 1 | `models/item/manual.json` | `textures/item/writable_book/manual.png` |

## Cómo agregar un ítem nuevo
1. Pon la textura en `textures/item/<carpeta>/<nombre>.png`
2. Crea el modelo en `models/item/<nombre>.json`, con `"layer0": "minecraft:item/<carpeta>/<nombre>"` apuntando exacto a esa textura
3. En `items/<base>.json`, agrega una entrada `threshold` con el `custom_model_data` que le asignarás y `"model": "minecraft:item/<nombre>"` (el nombre del ARCHIVO de modelo, no de la textura)
4. Asigna ese mismo `custom_model_data` al ítem desde CustomCrafting/plugin

**Error más común:** que el nombre en `items/*.json` no coincida con el nombre real del archivo en `models/item/`, o que la textura en el modelo no coincida con la ruta real en `textures/item/`. Eso fue justo lo que rompía `paper` y `writable_book` en la versión anterior.
